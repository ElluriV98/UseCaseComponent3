﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetApp.Service.TweetAppEntity;
using TweetApp.Service;
using Microsoft.Extensions.Logging;

namespace TweetApp
{
    //[EnableCors("MODPolicy")]
    [ApiController]
    [Produces("application/json")]
    public class TweetController : ControllerBase
    {
        private readonly ITweetCosmosService _cosmosDbService;
        private readonly ILogger<TweetController> _logger;

        /// <summary>
        /// Create the instance of the tweetController.
        /// </summary>
        /// <param name="service">service.</param>
        public TweetController(ITweetCosmosService cosmoDbService, ILogger<TweetController> logger)
        {
            this._cosmosDbService = cosmoDbService ?? throw new ArgumentNullException(nameof(cosmoDbService));
            this._logger =logger;
        }

        /// <summary>
        /// Adds the new tweet
        /// </summary>
        /// <param name="tweet">Tweet.</param>
        /// <returns>returns the status message.</returns>

        [Route("AddNewTweet")]
        [HttpPost]
        public IActionResult AddNewTweet([FromBody]Tweets tweet)
        {
            try
            {
                this._logger.LogInformation("Entered Add new tweet method in TweetController");
                if (tweet != null)
                {
                    tweet.TweetId = Guid.NewGuid().ToString();
                    this._cosmosDbService.AddNewPost(tweet);
                    return Ok(new { status = Constants.TweetAdded });
                }

                return Ok(new { status = Constants.TweetNotAdded });
            }
            catch (TweetException ex)
            {
                this._logger.LogError("Exception occured in Add New Tweet method :", ex.Message);
                throw new TweetException("error in add new tweet" + ex.Message);
            }
        }

        /// <summary>
        /// Views all user tweets.
        /// </summary>
        /// <param name="userId">userId.</param>
        /// <returns>returns all the user tweets.</returns>
        [Route("ViewUserAllTweets/{userId}")]
        [HttpGet]
        public async Task<IActionResult> ViewUserAllTweets(string userId)
        {
            try
            {
                this._logger.LogInformation("Entered view user all tweets method in TweetController");
                if (!string.IsNullOrEmpty(userId))
                {
                    var tweets = await this._cosmosDbService.GetUserTweets(userId);
                    return Ok(tweets);
                }
                return null;
            }
            catch (TweetException ex)
            {
                this._logger.LogError("Exception occured in Add new tweet method in TweetController",ex.Message);
                throw new TweetException("error in add new tweet" + ex.Message);
            }


        }

        /// <summary>
        /// Views all user tweets.
        /// </summary>
        /// <param name="userId">userId.</param>
        /// <returns>returns all the user tweets.</returns>
        [Route("ViewOtherUsersAllTweets/{userId}")]
        [HttpGet]
        public async Task<IActionResult> ViewOtherUsersAllTweets(string userId)
        {
            try
            {
                this._logger.LogInformation("Entered view other user all tweets method in TweetController");
                if (!string.IsNullOrEmpty(userId))
                {
                    var tweets = await this._cosmosDbService.GetOtherAllUserTweets(userId);
                    return Ok(tweets);
                }
                return null;
            }
            catch (TweetException ex)
            {
                this._logger.LogInformation("Entered view other user all tweets method in TweetController",ex.Message);
                throw new TweetException("error in add new tweet" + ex.Message);
            }


        }
    }
}
